from tkinter import *
from pandastable import Table, TableModel
import pandas as pd
from tkinter import filedialog
from functools import partial
from tkintertable.Tables import TableCanvas
from sklearn import linear_model
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from sklearn.cluster import AgglomerativeClustering,DBSCAN
import numpy as np
import scipy.cluster.hierarchy as sch
from scipy.cluster import hierarchy
from matplotlib import pyplot as plt
from scipy.cluster.vq import whiten, kmeans, vq, kmeans2
from collections import Counter
from sklearn.preprocessing import StandardScaler


Target = "Input" #input values to train or test
Y="Expected Output" #present in csv
predicted="by classfier" #model will predict
splitting_method = "gini"
(X_train, X_test, y_train, y_test) = [],[],[],[] 
df=""

col1=''
col2=''


def browseFiles():
	global df
	filePath = filedialog.askopenfilename(initialdir="/", title="Select a File",filetypes=(("all files", "*.*"), ("all files", "*.*")))
	df =  pd.read_csv(filePath)
	df.to_csv("util.csv")
	refresh(df)

def freshStart():
	global Target
	df = pd.DataFrame(index = ["NOTE:", "", ""], data = ["Upload a Dataset and"," select the target ","attribute"])
	df.to_csv("util.csv")

	refresh(df)

def setTarget(col):
	global X_train, X_test, y_train, y_test
	global Target
	Target = col
	# df = pd.read_csv("util.csv")
	

def setY(col):
	global Y
	Y=col

def setSplittingMethod(method):
	global splitting_method
	splitting_method = method

def check():
	df = pd.read_csv("util.csv")
	print(df[Target])
	print(df[Y])

def Regression():
	global Y,predicted, X_train, X_test, y_train, y_test
	if len(X_train)==0:
		X_train, X_test, y_train, y_test = train_test_split(df[[Target]], df[Y], test_size=0.2)
	reg=linear_model.LinearRegression()
	reg.fit(X_train,y_train)
	print("From Regression")
	print(reg.score(X_test,y_test))
	Y=y_test
	predicted=reg.predict(X_test)


def AGNES():
	global col1,col2
	data=df[[col1, col2]].to_numpy()
	# print(data)
	clustering = AgglomerativeClustering(n_clusters=2).fit(data)
	print(clustering.labels_)
	# dedrogram=sch.dendrogram(sch.linkage(data,method='warp'))
	Z = hierarchy.linkage(data, method='average')

	plt.figure()
	plt.title("Dendrograms")
	# Dendrogram plotting using linkage matrix
	dendrogram = hierarchy.dendrogram(Z)
	plt.show()

def means():
	global col1, col2
	data = np.array([df[col1], df[col2]])

	# normalize
	data = whiten(data)

	print(data)
	centroids, mean_value = kmeans(data, k=2)
	print("Code book :\n", centroids, "\n")	
	print("Mean of Euclidean distances :",mean_value.round(4))


def medoids():
	global col1, col2
	data = np.array([df[col1], df[col2]])

	# normalize
	data = whiten(data)

	print(data)
	centroids, mean_value = kmeans(data, k=2)
	print("Code book :\n", centroids, "\n")
	print("Mean of Euclidean distances :", mean_value.round(4))


def DBSCAN():
	dbscan_data=df[[col1,col2]]
	dbscan_data=dbscan_data.values.astype('float32',copy=False)
	print(dbscan_data)
	dbscan_data_scaler=StandardScaler().fit(dbscan_data)
	dbscan_data=dbscan_data_scaler.transform(dbscan_data)
	print(dbscan_data)
	model=DBSCAN(eps=0.3,min_samples=12,metric='euclidean').fit(dbscan_data)
	
	outliers_df=df[model.labels_==-1]
	clusters_df=df[model.labels_!=-1]



def setAttribute1(name):
	global col1
	col1=name
	# for id in range(len(col1)):
	# 	col1[id]=float(col1[id])


def setAttribute2(name):
	global col2
	col2=name
	# for id in range(len(col2)):
	# 	col2[id]=float(col2[id])

def appWindow():
	global root
	global Target
	root = Tk()
	root.title("Home page")
	root['background'] = '#9ea7e6'
	width= root.winfo_screenwidth() 
	height= root.winfo_screenheight()
	root.geometry("%dx%d" % (width, height))
	root.state('zoomed')

	df = pd.read_csv("util.csv")

	# Creating Menubar
	menubar = Menu(root)
	  
	Dataset = Menu(menubar, tearoff = 0)
	menubar.add_cascade(label ='Dataset', menu = Dataset)
	Dataset.add_command(label ='Upload', command = browseFiles)
	Dataset.add_command(label ='Delete', command = freshStart)
	
	Attribute1 = Menu(Dataset, tearoff=0)
	Dataset.add_cascade(label='Attribute 1', menu=Attribute1)
	for col in df.columns:
		Attribute1.add_command(label=col, command=partial(setAttribute1, col))
	
	Attribute2 = Menu(Dataset, tearoff=0)
	Dataset.add_cascade(label='Attribute 2', menu = Attribute2)
	for col in df.columns:
		Attribute2.add_command(label=col, command=partial(setAttribute2, col))

	Dataset.add_separator()
	Dataset.add_command(label ='Exit', command = root.destroy)
	
	
	clusters = Menu(menubar, tearoff = 0)
	k_value = Menu(clusters, tearoff=0)
	menubar.add_cascade(label='Cluster', menu=clusters)
	clusters.add_command(label='Hierarchical clustering - AGNES', command=AGNES)
	clusters.add_command(label='k-Means', command=means)
	clusters.add_command(label='k-Medoids (PAM)', command=medoids)
	clusters.add_command(label='DBSCAN', command=DBSCAN)

	# display Menu
	root.config(menu = menubar)

	tframe = Frame(root, bg = '#9ea7e6')
	tframe.pack(expand = True, fill = BOTH)
	table = TableCanvas(tframe)
	table.importCSV("util.csv", sep=',')
	table.show()

	root.mainloop()


def refresh(new_df):
	global Target
	global root

	try:
		root.destroy()
	except:
		pass

	new_df.to_csv("util.csv")
	appWindow()


if __name__ == "__main__":
	freshStart()
