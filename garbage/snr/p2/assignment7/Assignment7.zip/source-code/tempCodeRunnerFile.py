global col1,col2
	# data=df[[col1, col2]].to_numpy()
	# print(data)