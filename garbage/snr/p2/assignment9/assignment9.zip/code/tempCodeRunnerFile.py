
	# clusters.add_command(label='set parameters', command=set_parameters)
	# clusters.add_command(label='apriori', command=apriori)